// este es el apartado de pagos para poder realizarlos en la pagina web // 
document.getElementById("procesarPago").addEventListener("click", function() {
    const tarjeta = document.getElementById("tarjeta").value;
    const nombre = document.getElementById("nombre").value;
    const cvv = document.getElementById("cvv").value;

    if (tarjeta === "" || nombre === "" || cvv === "") {
        document.getElementById("resultadoPago").innerHTML = "<div class='alert alert-danger'>Por favor, complete todos los campos.</div>";
        return;
    }

    if (!esTarjetaValida(tarjeta)) {
        document.getElementById("resultadoPago").innerHTML = "<div class='alert alert-danger'>Ingrese una tarjeta válida.</div>";
        return;
    }

    $.post("/metodo_pago", { tarjeta: tarjeta, nombre: nombre, cvv: cvv })
        .done(function(data) {
            document.getElementById("resultadoPago").innerHTML = "<div class='alert alert-success'>" + data + "</div>";
        })
        .fail(function(xhr) {
            document.getElementById("resultadoPago").innerHTML = "<div class='alert alert-danger'>" + xhr.responseText + "</div>";
        });
});

function esTarjetaValida(numeroTarjeta) {
    const numeroLimpiado = numeroTarjeta.replace(/\D/g, '');

    if (numeroLimpiado.length !== 16) {
        return false;
    }

    let suma = 0;
    let doble = false;

    for (let i = numeroLimpiado.length - 1; i >= 0; i--) {
        let digito = parseInt(numeroLimpiado.charAt(i), 10);

        if (doble) {
            digito *= 2;
            if (digito > 9) {
                digito -= 9;
            }
        }

        suma += digito;
        doble = !doble;
    }

    return suma % 10 === 0;
}
const tarjetaValida = esTarjetaValida('1234 5678 9012 3456'); 
console.log(tarjetaValida); 




