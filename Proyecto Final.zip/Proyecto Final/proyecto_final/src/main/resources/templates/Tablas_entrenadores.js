document.getElementById("saveBtn").addEventListener("click", function() {
    const nombre = document.getElementById("nombre").value;
    const diaEntrenamiento = document.getElementById("diaEntrenamiento").value;
    const claseTomada = document.getElementById("claseTomada").value;
    const horaInicio = document.getElementById("horaInicio").value;
    const horaFin = document.getElementById("horaFin").value;

    const entrenamiento = {
        nombre: nombre,
        diaEntrenamiento: diaEntrenamiento,
        claseTomada: claseTomada,
        horaInicio: horaInicio,
        horaFin: horaFin
    };

    
    fetch('/entrenamientos/save', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(entrenamiento),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error al guardar el entrenamiento.');
        }
        return response.json();
    })
    .then(data => {
       
        console.log('Entrenamiento guardado con éxito:', data);
    })
    .catch(error => {
       
        console.error('Error al guardar el entrenamiento:', error.message);
    });
});