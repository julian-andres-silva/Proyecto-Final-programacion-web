function changeLanguage(language) {
    const buttonsContainer = document.getElementById('language-buttons');
    const textsToChange = document.querySelectorAll("[data-section]");

    const fetchLanguageData = async (language) => {
        const requestJson = await fetch(`./languages/${language}.json`);
        return await requestJson.json();
    };

    const applyTranslations = async (language) => {
        const texts = await fetchLanguageData(language);

        for (const textToChange of textsToChange) {
            const section = textToChange.dataset.section;
            const value = textToChange.dataset.value;

            console.log(section, value);

            textToChange.innerHTML = texts[section][value];
        }
    };

    buttonsContainer.addEventListener("click", (e) => {
        if (e.target.tagName === "BUTTON") {
            applyTranslations(e.target.dataset.languages);
        }
    });

}


changeLanguage('en');