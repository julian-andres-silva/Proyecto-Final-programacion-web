document.getElementById("registroForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const formData = new FormData(event.target);

    fetch("/registro/registro", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(Object.fromEntries(formData)),
    })
        .then(response => response.json())
        .then(data => {
            console.log("Éxito:", data);
            
        })
        .catch(error => {
            console.error("Error:", error);
            
        });
});