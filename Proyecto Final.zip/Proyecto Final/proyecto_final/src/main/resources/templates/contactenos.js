document.getElementById("procesarContacto").addEventListener("click", function() {
    const nombre = document.getElementById("nombre").value;
    const email = document.getElementById("email").value;
    const telefono = document.getElementById("telefono").value;

    if (nombre === "" || email === "" || telefono === "") {
        document.getElementById("resultadoContacto").innerHTML = "<div class='alert alert-danger'>Por favor, complete todos los campos.</div>";
        return;
    }

    
    fetch('/contacto', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ nombre, email, telefono }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error al procesar el contacto.');
        }
        return response.json();
    })
    .then(data => {
        document.getElementById("resultadoContacto").innerHTML = "<div class='alert alert-success'>" + data + "</div>";
    })
    .catch(error => {
        document.getElementById("resultadoContacto").innerHTML = "<div class='alert alert-danger'>" + error.message + "</div>";
    });
});