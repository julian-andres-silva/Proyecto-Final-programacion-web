document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault(); 

    const correo = document.getElementById("correo").value;
    const contraseña = document.getElementById("contraseña").value;

  
    const formData = {
        correo: correo,
        contraseña: contraseña
    };

  
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
    };

    
    fetch("/login", requestOptions)
        .then(response => {
            if (!response.ok) {
                throw new Error("Credenciales inválidas");
            }
          
            window.location.href = "/PF PW.html";
        })
        .catch(error => {
        
            console.error("Error de inicio de sesión:", error.message);
        });
});