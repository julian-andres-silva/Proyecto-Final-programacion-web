package com.proyecto_final.gimnasio_fighting.Entidades;




public class PagoRequest {
    private String tarjeta;
    private String nombre;
    private String cvv;

    public PagoRequest() {
    }

    public PagoRequest(String tarjeta, String nombre, String cvv) {
        this.tarjeta = tarjeta;
        this.nombre = nombre;
        this.cvv = cvv;
    }

    public String getTarjeta() {
        return tarjeta;
    }

    public void setTarjeta(String tarjeta) {
        this.tarjeta = tarjeta;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }
}