package com.proyecto_final.gimnasio_fighting.Servicios;

import com.proyecto_final.gimnasio_fighting.Entidades.Usuario;
import com.proyecto_final.gimnasio_fighting.Repositorio.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public boolean autenticarUsuario(String correo, String contraseña) {
        Usuario usuario = usuarioRepository.findBYCorreo(correo);

        if (usuario != null) {

            return passwordEncoder.matches(contraseña, usuario.getContraseña());
        }

        return false;
    }
}