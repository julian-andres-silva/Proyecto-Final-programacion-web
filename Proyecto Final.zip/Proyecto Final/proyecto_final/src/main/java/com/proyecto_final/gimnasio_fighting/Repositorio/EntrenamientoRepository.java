package com.proyecto_final.gimnasio_fighting.Repositorio;

import com.proyecto_final.gimnasio_fighting.Entidades.Entrenamiento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EntrenamientoRepository extends JpaRepository<Entrenamiento, Long> {

}