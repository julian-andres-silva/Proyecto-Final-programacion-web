package com.proyecto_final.gimnasio_fighting.Repositorio;


import com.proyecto_final.gimnasio_fighting.Entidades.Usuario;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsuarioRepository extends CrudRepository<Usuario,Long> {
    Usuario findBYCorreo(String correo);
}