package com.proyecto_final.gimnasio_fighting.Servicios;

import com.proyecto_final.gimnasio_fighting.Entidades.Entrenamiento;
import com.proyecto_final.gimnasio_fighting.Repositorio.EntrenamientoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EntrenamientoService {
    @Autowired
    private EntrenamientoRepository entrenamientoRepository;

    public List<Entrenamiento> getAllEntrenamiento() {
        return entrenamientoRepository.findAll();
    }

    public Entrenamiento saveEntrenamiento(Entrenamiento entrenamiento) {
        return entrenamientoRepository.save(entrenamiento);
    }
}