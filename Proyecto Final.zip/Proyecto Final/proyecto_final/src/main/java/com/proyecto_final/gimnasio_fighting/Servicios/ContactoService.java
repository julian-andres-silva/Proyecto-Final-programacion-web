package com.proyecto_final.gimnasio_fighting.Servicios;

import com.proyecto_final.gimnasio_fighting.Entidades.Contacto;
import com.proyecto_final.gimnasio_fighting.Repositorio.ContactoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ContactoService {
    @Autowired
    private ContactoRepository contactoRepository;

    public void guardarContacto(Contacto contacto) {



        contactoRepository.save(contacto);
    }
}