package com.proyecto_final.gimnasio_fighting.Controladores;

import com.proyecto_final.gimnasio_fighting.Entidades.Contacto;
import com.proyecto_final.gimnasio_fighting.Servicios.ContactoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ContactoController {
    @Autowired
    private ContactoService contactoService;


    @GetMapping("/contacto")
    public String mostrarFormularioContacto(Model model){
        model.addAttribute("contacto", new Contacto());
        return "PF PW.html";
    }

    @PostMapping("/contacto")
    public String procesarFormularioContacto(Contacto contacto) {
        contactoService.guardarContacto(contacto);
        return "redirect:/contacto-confirmacion.html";
    }
}