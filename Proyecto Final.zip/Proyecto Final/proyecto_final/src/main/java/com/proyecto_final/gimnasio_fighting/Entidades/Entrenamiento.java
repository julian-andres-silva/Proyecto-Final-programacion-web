package com.proyecto_final.gimnasio_fighting.Entidades;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import org.springframework.data.annotation.Id;

@Entity
public class Entrenamiento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String diaEntrenamiento;
    private String claseTomada;
    private String horaInicio;
    private String horaFin;


    public Entrenamiento() {
    }

    public Entrenamiento(Long id, String nombre, String diaEntrenamiento, String claseTomada, String horaInicio, String horaFin) {
        this.id = id;
        this.nombre = nombre;
        this.diaEntrenamiento = diaEntrenamiento;
        this.claseTomada = claseTomada;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDiaEntrenamiento() {
        return diaEntrenamiento;
    }

    public void setDiaEntrenamiento(String diaEntrenamiento) {
        this.diaEntrenamiento = diaEntrenamiento;
    }

    public String getClaseTomada() {
        return claseTomada;
    }

    public void setClaseTomada(String claseTomada) {
        this.claseTomada = claseTomada;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public String getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(String horaFin) {
        this.horaFin = horaFin;
    }

}
