package com.proyecto_final.gimnasio_fighting.Controladores;

import com.proyecto_final.gimnasio_fighting.Entidades.Usuario;
import com.proyecto_final.gimnasio_fighting.Repositorio.EntrenamientoRepository;
import com.proyecto_final.gimnasio_fighting.Repositorio.UsuarioRepository;
import com.proyecto_final.gimnasio_fighting.Servicios.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;

@Controller
public class LoginController {
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private EntrenamientoRepository entrenamientoRepository;

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/login")
    public String mostrarFormularioLogin(Model model) {
        model.addAttribute("clasesEntrenamiento", entrenamientoRepository.findAll());
        return "iniciar sesion.html";
    }

    @PostMapping("/login")
    public String procesarLogin(Model model, @RequestParam String correo, @RequestParam String contraseña, Principal principal) {
        Usuario usuario = usuarioRepository.findBYCorreo(correo);
        if (usuario != null && verificarContraseña(contraseña, usuario.getContraseña())) {
            return "redirect:/PF PW.html";
        } else {
            model.addAttribute("error", "Credenciales Inválidas, Por favor, inténtelo de nuevo");
        }
        model.addAttribute("clasesEntrenamiento", entrenamientoRepository.findAll());
        return "iniciar sesion.html";
    }

    @RequestMapping("/entrenadores")
    public String mostrarEntrenadores(Model model) {
        model.addAttribute("entrenador", entrenamientoRepository.findAll());
        return "Tabla_entrenadores.html";
    }

    private boolean verificarContraseña(String contraseñaIngresada, String contraseñaAlmacenada) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        return passwordEncoder.matches(contraseñaIngresada, contraseñaAlmacenada);
    }
}
