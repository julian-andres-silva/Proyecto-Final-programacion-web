package com.proyecto_final.gimnasio_fighting.Controladores;

import com.proyecto_final.gimnasio_fighting.Entidades.Usuario;
import com.proyecto_final.gimnasio_fighting.Repositorio.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class RegistroController {
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @GetMapping("/registro")
    public String mostrarformularioregistrarse() {

        return "registrarse";
    }

    @PostMapping("/registro")
    public String procesarRegistro(@ModelAttribute("usuario") Usuario usuario){
        if(usuarioRepository.findBYCorreo(usuario.getCorreo()) !=null) {
            return "redirect:/registrarse?error=exists";
        }
        usuario.setContraseña(passwordEncoder.encode(usuario.getContraseña()));

        usuarioRepository.save(usuario);

        return "redirect:/iniciar sesion.html";

    }

}