package com.proyecto_final.gimnasio_fighting.Controladores;

import com.proyecto_final.gimnasio_fighting.Entidades.Entrenamiento;
import com.proyecto_final.gimnasio_fighting.Entidades.Usuario;
import com.proyecto_final.gimnasio_fighting.Repositorio.EntrenamientoRepository;
import com.proyecto_final.gimnasio_fighting.Servicios.EntrenamientoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/entrenamientos")
public class EntrenamientoController {

    @Autowired
    private EntrenamientoService entrenamientoService;

    @Autowired
    private EntrenamientoRepository entrenamientoRepository;

    @GetMapping("")
    public String entrenamiento(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        boolean userAuthenticated = auth.isAuthenticated() && !auth.getName().equals("anonymousUser");

        model.addAttribute("userAuthenticated", userAuthenticated);
        model.addAttribute("entrenamientos", entrenamientoRepository.findAll());

        return "entrenamiento";
    }

    @GetMapping("/all")
    public ResponseEntity<List<Entrenamiento>> getAllEntrenamiento() {
        List<Entrenamiento> entrenamientos = entrenamientoService.getAllEntrenamiento();
        return new ResponseEntity<>(entrenamientos, HttpStatus.OK);
    }

    @PostMapping("/save")
    public ResponseEntity<Entrenamiento> saveEntrenamiento(@RequestBody Entrenamiento entrenamiento,
                                                           @AuthenticationPrincipal Usuario usuario) {
        if (usuario != null) {
            Entrenamiento savedEntrenamiento = entrenamientoService.saveEntrenamiento(entrenamiento);
            return new ResponseEntity<>(savedEntrenamiento, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
    }
}
