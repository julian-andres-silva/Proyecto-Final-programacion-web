package com.proyecto_final.gimnasio_fighting.Controladores;

import com.proyecto_final.gimnasio_fighting.Entidades.PagoRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PagoController {
    @PostMapping("/metodo_pago")
    public ResponseEntity<String> procesarPago(@RequestBody PagoRequest pagoRequest) {
        try {
            String tarjeta = pagoRequest.getTarjeta();
            String nombre = pagoRequest.getNombre();
            String cvv = pagoRequest.getCvv();

            if (esTarjetaValida(tarjeta)) {
                return ResponseEntity.ok("Pago exitoso.");
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No se pudo procesar el pago. Tarjeta inválida.");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al procesar el pago: " + e.getMessage());
        }
    }

    private boolean esTarjetaValida(String numeroTarjeta) {
        int suma = 0;
        boolean doble = false;

        for (int i = numeroTarjeta.length() - 1; i >= 0; i--) {
            int digito = numeroTarjeta.charAt(i) - '0';

            if (doble) {
                digito *= 2;
                if (digito > 9) {
                    digito -= 9;
                }
            }

            suma += digito;
            doble = !doble;
        }

        return (suma % 10 == 0);
    }
}