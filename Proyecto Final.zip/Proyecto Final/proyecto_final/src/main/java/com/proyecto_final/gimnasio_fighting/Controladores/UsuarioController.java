package com.proyecto_final.gimnasio_fighting.Controladores;

import com.proyecto_final.gimnasio_fighting.Entidades.Usuario;
import com.proyecto_final.gimnasio_fighting.Repositorio.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/registro")
public class UsuarioController {
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @PostMapping("/registro")
    public ResponseEntity<String> procesarRegistro(@RequestBody Usuario usuario) {
        try {
            System.out.println("Recibiendo datos de registro: " + usuario.toString());


            Usuario existingUser = usuarioRepository.findBYCorreo(usuario.getCorreo());
            if (existingUser != null) {
                System.out.println("Correo electrónico ya registrado");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Correo electrónico ya registrado");
            }


            usuario.setContraseña(passwordEncoder.encode(usuario.getContraseña()));
            usuarioRepository.save(usuario);

            System.out.println("Registro exitoso");
            return ResponseEntity.ok("Registro exitoso");
        } catch (Exception e) {
            System.err.println("Error en el servidor: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error en el servidor");
        }
    }
}